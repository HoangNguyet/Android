package com.example.happy_read.adapter;

public class RatingAdapter {
//    Hiển thị danh sách các đánh giá của người dùng về một truyện
}
