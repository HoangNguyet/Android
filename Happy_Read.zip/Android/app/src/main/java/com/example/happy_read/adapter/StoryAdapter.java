package com.example.happy_read.adapter;

public class StoryAdapter {

//    Hiển thị danh sách các truyện
}
