package com.example.happy_read.activity;

public class UserProfileActivity {
//    Hiển thị thông tin người dùng và truyện mà họ đã đọc và yêu thích
}
