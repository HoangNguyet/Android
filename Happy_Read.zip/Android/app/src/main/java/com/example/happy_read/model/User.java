package com.example.happy_read.model;

public class User {
}
