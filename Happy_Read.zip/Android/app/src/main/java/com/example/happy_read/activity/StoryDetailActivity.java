package com.example.happy_read.activity;

public class StoryDetailActivity {
//    Hiển thị chi tiết truyện khi người dùng chọn một truyện cụ thể
}
